// ============================================================
// AXI Onboarding Hub — Google Apps Script Backend
// Paste this entire file into your Apps Script editor
// Deploy as a Web App (Anyone can access) to get your URL
// ============================================================

const SHEET_NAME = "Shay Onboarding";

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action;

    if (action === "save") {
      return saveProgress(data.payload);
    } else if (action === "load") {
      return loadProgress();
    }

    return respond({ success: false, error: "Unknown action" });
  } catch (err) {
    return respond({ success: false, error: err.toString() });
  }
}

function doGet(e) {
  const action = e.parameter.action;
  if (action === "load") {
    return loadProgress();
  }
  return respond({ success: false, error: "Use POST to save, GET?action=load to load" });
}

function saveProgress(payload) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    setupSheet(sheet);
  }

  const now = new Date().toLocaleString("en-US", { timeZone: "America/New_York" });

  // Write to a single data row (row 2 onwards, using row 2 as current state)
  // Row 1 = headers, Row 2 = current state, Row 3+ = history log

  // Update current state row
  const completedDays = payload.completedDays || {};
  const taskChecks = payload.taskChecks || {};
  const dayNotes = payload.dayNotes || {};

  const daysComplete = Object.values(completedDays).filter(Boolean).length;
  const tasksComplete = Object.values(taskChecks).filter(Boolean).length;
  const pct = Math.round(daysComplete / 30 * 100);

  // Serialize notes that have content
  const notesWithContent = Object.entries(dayNotes)
    .filter(([k, v]) => v && v.trim())
    .map(([k, v]) => `Day ${k}: ${v.trim()}`)
    .join(" | ");

  // Build completed days string
  const completedDaysList = Object.entries(completedDays)
    .filter(([k, v]) => v)
    .map(([k]) => k)
    .sort((a, b) => Number(a) - Number(b))
    .join(", ");

  // Current state row (always row 2)
  sheet.getRange(2, 1, 1, 8).setValues([[
    now,
    daysComplete,
    tasksComplete,
    pct + "%",
    completedDaysList || "None yet",
    tasksComplete + " / 150",
    notesWithContent || "No notes yet",
    JSON.stringify(payload).substring(0, 500) // Raw snapshot (truncated)
  ]]);

  // Color the progress cell based on completion
  const pctCell = sheet.getRange(2, 4);
  if (pct >= 80) {
    pctCell.setBackground("#c6efce").setFontColor("#276221");
  } else if (pct >= 40) {
    pctCell.setBackground("#ffeb9c").setFontColor("#9c6500");
  } else {
    pctCell.setBackground("#ffc7ce").setFontColor("#9c0006");
  }

  // Append a history log row
  const lastRow = Math.max(sheet.getLastRow(), 2);
  sheet.getRange(lastRow + 1, 1, 1, 5).setValues([[
    now,
    "Auto-save",
    daysComplete + "/30 days",
    tasksComplete + " tasks",
    pct + "% complete"
  ]]);

  // Update the day-by-day breakdown sheet
  updateDayBreakdown(ss, completedDays, taskChecks, dayNotes);

  return respond({ success: true, savedAt: now });
}

function loadProgress() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);

  if (!sheet || sheet.getLastRow() < 2) {
    return respond({ success: true, payload: null });
  }

  const rawSnapshot = sheet.getRange(2, 8).getValue();
  try {
    const payload = JSON.parse(rawSnapshot);
    return respond({ success: true, payload: payload });
  } catch (e) {
    return respond({ success: true, payload: null });
  }
}

function setupSheet(sheet) {
  // Main progress tab headers
  const headers = [
    "Last Updated (ET)",
    "Days Complete",
    "Tasks Complete",
    "% Done",
    "Completed Days",
    "Task Progress",
    "Day Notes Summary",
    "Raw Snapshot"
  ];
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.getRange(1, 1, 1, headers.length)
    .setBackground("#0C447C")
    .setFontColor("#ffffff")
    .setFontWeight("bold");
  sheet.setColumnWidth(1, 180);
  sheet.setColumnWidth(5, 200);
  sheet.setColumnWidth(7, 300);
  sheet.setColumnWidth(8, 80);
  sheet.hideColumns(8); // Hide raw snapshot column
}

function updateDayBreakdown(ss, completedDays, taskChecks, dayNotes) {
  const breakdownName = "Day Breakdown";
  let bSheet = ss.getSheetByName(breakdownName);

  if (!bSheet) {
    bSheet = ss.insertSheet(breakdownName);
    const bHeaders = ["Day", "Theme", "Status", "Tasks Done", "Notes"];
    bSheet.getRange(1, 1, 1, 5).setValues([bHeaders]);
    bSheet.getRange(1, 1, 1, 5)
      .setBackground("#0C447C")
      .setFontColor("#ffffff")
      .setFontWeight("bold");
    bSheet.setColumnWidth(2, 200);
    bSheet.setColumnWidth(5, 300);
  }

  const themes = [
    "Welcome & orientation", "AXI business model", "Meet the CFO Office", "Meet Investments",
    "Meet Operations & Technology", "Week 1 reflection", "AXI strategy & priorities",
    "Blue Book deep dive", "Meet Legal & Compliance", "Budget & forecasting cycle",
    "Initiative tracking", "Meet People & HR", "Investor prep context", "Week 2 reflection",
    "Your first deliverable", "Communication norms", "Technology & tools", "CFO priorities deep dive",
    "Entity & restructuring overview", "Strategic initiative deep dive", "Week 3 reflection",
    "Remote visibility strategy", "Build your stakeholder map", "Performance metrics draft",
    "Shadow a key meeting", "Draft your 60-day plan", "Reference library review",
    "Process improvement proposal", "Wrap up month 1", "30-day check-in"
  ];

  const rows = [];
  for (let d = 1; d <= 30; d++) {
    const done = completedDays[d] ? "Complete" : "Pending";
    const tasksDone = [0,1,2,3,4].filter(i => taskChecks[`d${d}_${i}`]).length;
    const note = dayNotes[d] || "";
    rows.push([d, themes[d - 1] || "", done, `${tasksDone}/5`, note]);
  }

  bSheet.getRange(2, 1, 30, 5).setValues(rows);

  // Color rows by status
  for (let i = 0; i < 30; i++) {
    const statusCell = bSheet.getRange(i + 2, 3);
    if (rows[i][2] === "Complete") {
      statusCell.setBackground("#c6efce").setFontColor("#276221");
    } else {
      statusCell.setBackground("#ffc7ce").setFontColor("#9c0006");
    }
  }
}

function respond(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
